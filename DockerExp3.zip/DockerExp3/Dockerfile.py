FROM python:3
WORKDIR /app
COPY requirements.txt
RUN pip install --no--chache-dir -r requirements.txt
COPY . .
EXPOSE 8051
CMD ["streamlit","run","main.py"]